CREATE TABLE `box_3_wysija_email_user_url` (  `email_id` int(10) unsigned NOT NULL,  `user_id` int(10) unsigned NOT NULL,  `url_id` int(10) unsigned NOT NULL,  `clicked_at` int(10) unsigned DEFAULT NULL,  `number_clicked` int(10) unsigned NOT NULL DEFAULT '0',  PRIMARY KEY (`user_id`,`email_id`,`url_id`)) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40000 ALTER TABLE `box_3_wysija_email_user_url` DISABLE KEYS */;
SET FOREIGN_KEY_CHECKS = 0;
SET UNIQUE_CHECKS = 0;
/*!40000 ALTER TABLE `box_3_wysija_email_user_url` ENABLE KEYS */;
SET FOREIGN_KEY_CHECKS = 1;
SET UNIQUE_CHECKS = 1;
