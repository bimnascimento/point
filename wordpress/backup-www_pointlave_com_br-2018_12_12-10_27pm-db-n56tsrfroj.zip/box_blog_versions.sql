CREATE TABLE `box_blog_versions` (  `blog_id` bigint(20) NOT NULL DEFAULT '0',  `db_version` varchar(20) NOT NULL DEFAULT '',  `last_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',  PRIMARY KEY (`blog_id`),  KEY `db_version` (`db_version`)) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40000 ALTER TABLE `box_blog_versions` DISABLE KEYS */;
SET FOREIGN_KEY_CHECKS = 0;
SET UNIQUE_CHECKS = 0;
/*!40000 ALTER TABLE `box_blog_versions` ENABLE KEYS */;
SET FOREIGN_KEY_CHECKS = 1;
SET UNIQUE_CHECKS = 1;
