CREATE TABLE `box_hplugin_root` (  `hplugin_id` int(11) NOT NULL AUTO_INCREMENT,  `plugin_name` varchar(45) NOT NULL,  `plugin_version` varchar(10) NOT NULL,  `plugin_uuid` varchar(36) NOT NULL,  `date_created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,  `last_modified` datetime DEFAULT NULL,  `active` tinyint(1) NOT NULL DEFAULT '1',  `deleted` tinyint(1) NOT NULL DEFAULT '0',  PRIMARY KEY (`hplugin_id`)) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40000 ALTER TABLE `box_hplugin_root` DISABLE KEYS */;
SET FOREIGN_KEY_CHECKS = 0;
SET UNIQUE_CHECKS = 0;
INSERT INTO `box_hplugin_root` VALUES('1', 'hmapsprem', '2.1.5', '26ae0ef9-4dc0-4a82-90e6-bf9ccc9889a2', '2017-05-26 00:10:49', NULL, '1', '0');
/*!40000 ALTER TABLE `box_hplugin_root` ENABLE KEYS */;
SET FOREIGN_KEY_CHECKS = 1;
SET UNIQUE_CHECKS = 1;
