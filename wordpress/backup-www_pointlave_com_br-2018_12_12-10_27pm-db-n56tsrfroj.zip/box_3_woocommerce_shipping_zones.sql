CREATE TABLE `box_3_woocommerce_shipping_zones` (  `zone_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,  `zone_name` varchar(200) NOT NULL,  `zone_order` bigint(20) unsigned NOT NULL,  PRIMARY KEY (`zone_id`)) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40000 ALTER TABLE `box_3_woocommerce_shipping_zones` DISABLE KEYS */;
SET FOREIGN_KEY_CHECKS = 0;
SET UNIQUE_CHECKS = 0;
/*!40000 ALTER TABLE `box_3_woocommerce_shipping_zones` ENABLE KEYS */;
SET FOREIGN_KEY_CHECKS = 1;
SET UNIQUE_CHECKS = 1;
