CREATE TABLE `box_2_sumo_reward_send_point_submitted_data` (  `id` mediumint(9) NOT NULL AUTO_INCREMENT,  `userid` int(225) DEFAULT NULL,  `userloginname` varchar(200) DEFAULT NULL,  `pointstosend` varchar(200) DEFAULT NULL,  `sendercurrentpoints` varchar(200) DEFAULT NULL,  `status` varchar(200) DEFAULT NULL,  `selecteduser` longtext NOT NULL,  `date` varchar(300) DEFAULT NULL,  UNIQUE KEY `id` (`id`)) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40000 ALTER TABLE `box_2_sumo_reward_send_point_submitted_data` DISABLE KEYS */;
SET FOREIGN_KEY_CHECKS = 0;
SET UNIQUE_CHECKS = 0;
/*!40000 ALTER TABLE `box_2_sumo_reward_send_point_submitted_data` ENABLE KEYS */;
SET FOREIGN_KEY_CHECKS = 1;
SET UNIQUE_CHECKS = 1;
