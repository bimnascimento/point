CREATE TABLE `box_revslider_static_slides` (  `id` int(9) NOT NULL AUTO_INCREMENT,  `slider_id` int(9) NOT NULL,  `params` longtext NOT NULL,  `layers` longtext NOT NULL,  `settings` text NOT NULL,  UNIQUE KEY `id` (`id`)) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40000 ALTER TABLE `box_revslider_static_slides` DISABLE KEYS */;
SET FOREIGN_KEY_CHECKS = 0;
SET UNIQUE_CHECKS = 0;
INSERT INTO `box_revslider_static_slides` VALUES('1', '1', '{\"background_type\":\"trans\",\"image\":\"https:\\/\\/www.pointlave.com.br\\/wp-content\\/uploads\\/\"}', '[]', '[]');
INSERT INTO `box_revslider_static_slides` VALUES('2', '3', '{\"staticoverflow\":\"visible\",\"image_id\":\"\",\"image\":\"\"}', '[]', '\"\"');
/*!40000 ALTER TABLE `box_revslider_static_slides` ENABLE KEYS */;
SET FOREIGN_KEY_CHECKS = 1;
SET UNIQUE_CHECKS = 1;
