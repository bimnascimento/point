CREATE TABLE `box_3_yith_wcch_emails` (  `id` bigint(20) NOT NULL AUTO_INCREMENT,  `sender_name` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT NULL,  `sender_email` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT NULL,  `user_id` bigint(20) DEFAULT NULL,  `subject` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT NULL,  `content` text COLLATE utf8mb4_unicode_ci,  `reg_date` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',  `del` tinyint(1) NOT NULL DEFAULT '0',  PRIMARY KEY (`id`)) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40000 ALTER TABLE `box_3_yith_wcch_emails` DISABLE KEYS */;
SET FOREIGN_KEY_CHECKS = 0;
SET UNIQUE_CHECKS = 0;
/*!40000 ALTER TABLE `box_3_yith_wcch_emails` ENABLE KEYS */;
SET FOREIGN_KEY_CHECKS = 1;
SET UNIQUE_CHECKS = 1;
