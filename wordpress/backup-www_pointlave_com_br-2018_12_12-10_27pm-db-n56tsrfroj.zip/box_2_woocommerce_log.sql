CREATE TABLE `box_2_woocommerce_log` (  `log_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,  `timestamp` datetime NOT NULL,  `level` smallint(4) NOT NULL,  `source` varchar(200) NOT NULL,  `message` longtext NOT NULL,  `context` longtext,  PRIMARY KEY (`log_id`),  KEY `level` (`level`)) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40000 ALTER TABLE `box_2_woocommerce_log` DISABLE KEYS */;
SET FOREIGN_KEY_CHECKS = 0;
SET UNIQUE_CHECKS = 0;
/*!40000 ALTER TABLE `box_2_woocommerce_log` ENABLE KEYS */;
SET FOREIGN_KEY_CHECKS = 1;
SET UNIQUE_CHECKS = 1;
