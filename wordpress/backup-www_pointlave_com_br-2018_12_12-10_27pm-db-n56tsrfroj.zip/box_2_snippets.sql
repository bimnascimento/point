CREATE TABLE `box_2_snippets` (  `id` bigint(20) NOT NULL AUTO_INCREMENT,  `name` tinytext NOT NULL,  `description` text NOT NULL,  `code` longtext NOT NULL,  `tags` longtext NOT NULL,  `scope` tinyint(1) NOT NULL DEFAULT '0',  `active` tinyint(1) NOT NULL DEFAULT '0',  PRIMARY KEY (`id`)) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40000 ALTER TABLE `box_2_snippets` DISABLE KEYS */;
SET FOREIGN_KEY_CHECKS = 0;
SET UNIQUE_CHECKS = 0;
/*!40000 ALTER TABLE `box_2_snippets` ENABLE KEYS */;
SET FOREIGN_KEY_CHECKS = 1;
SET UNIQUE_CHECKS = 1;
