CREATE TABLE `box_2_yith_wcch_emails` (  `id` bigint(20) NOT NULL AUTO_INCREMENT,  `sender_name` varchar(250) DEFAULT NULL,  `sender_email` varchar(250) DEFAULT NULL,  `user_id` bigint(20) DEFAULT NULL,  `subject` varchar(250) DEFAULT NULL,  `content` text,  `reg_date` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',  `del` tinyint(1) NOT NULL DEFAULT '0',  PRIMARY KEY (`id`)) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40000 ALTER TABLE `box_2_yith_wcch_emails` DISABLE KEYS */;
SET FOREIGN_KEY_CHECKS = 0;
SET UNIQUE_CHECKS = 0;
INSERT INTO `box_2_yith_wcch_emails` VALUES('1', 'adm', 'adm@pointlave.com.br', '32', 'teste', 'teste', '2017-10-12 11:40:08', '0');
/*!40000 ALTER TABLE `box_2_yith_wcch_emails` ENABLE KEYS */;
SET FOREIGN_KEY_CHECKS = 1;
SET UNIQUE_CHECKS = 1;
