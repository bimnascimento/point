CREATE TABLE `box_2_woocommerce_downloadable_product_permissions` (  `permission_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,  `download_id` varchar(32) NOT NULL,  `product_id` bigint(20) unsigned NOT NULL,  `order_id` bigint(20) unsigned NOT NULL DEFAULT '0',  `order_key` varchar(200) NOT NULL,  `user_email` varchar(200) NOT NULL,  `user_id` bigint(20) unsigned DEFAULT NULL,  `downloads_remaining` varchar(9) DEFAULT NULL,  `access_granted` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',  `access_expires` datetime DEFAULT NULL,  `download_count` bigint(20) unsigned NOT NULL DEFAULT '0',  PRIMARY KEY (`permission_id`),  KEY `download_order_key_product` (`product_id`,`order_id`,`order_key`(16),`download_id`),  KEY `download_order_product` (`download_id`,`order_id`,`product_id`)) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40000 ALTER TABLE `box_2_woocommerce_downloadable_product_permissions` DISABLE KEYS */;
SET FOREIGN_KEY_CHECKS = 0;
SET UNIQUE_CHECKS = 0;
/*!40000 ALTER TABLE `box_2_woocommerce_downloadable_product_permissions` ENABLE KEYS */;
SET FOREIGN_KEY_CHECKS = 1;
SET UNIQUE_CHECKS = 1;
