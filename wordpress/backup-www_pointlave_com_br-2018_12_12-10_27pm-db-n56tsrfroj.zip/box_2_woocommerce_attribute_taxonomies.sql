CREATE TABLE `box_2_woocommerce_attribute_taxonomies` (  `attribute_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,  `attribute_name` varchar(200) NOT NULL,  `attribute_label` varchar(200) DEFAULT NULL,  `attribute_type` varchar(20) NOT NULL,  `attribute_orderby` varchar(20) NOT NULL,  `attribute_public` int(1) NOT NULL DEFAULT '1',  PRIMARY KEY (`attribute_id`),  KEY `attribute_name` (`attribute_name`(20))) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40000 ALTER TABLE `box_2_woocommerce_attribute_taxonomies` DISABLE KEYS */;
SET FOREIGN_KEY_CHECKS = 0;
SET UNIQUE_CHECKS = 0;
INSERT INTO `box_2_woocommerce_attribute_taxonomies` VALUES('1', 'prazo', 'Prazo', 'text', 'name', '0');
/*!40000 ALTER TABLE `box_2_woocommerce_attribute_taxonomies` ENABLE KEYS */;
SET FOREIGN_KEY_CHECKS = 1;
SET UNIQUE_CHECKS = 1;
