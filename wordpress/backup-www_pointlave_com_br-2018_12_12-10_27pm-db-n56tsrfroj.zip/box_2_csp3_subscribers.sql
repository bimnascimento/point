CREATE TABLE `box_2_csp3_subscribers` (  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,  `email` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,  `fname` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,  `lname` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,  `clicks` int(11) NOT NULL DEFAULT '0',  `conversions` int(11) NOT NULL DEFAULT '0',  `referrer` int(11) NOT NULL DEFAULT '0',  `ip` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,  PRIMARY KEY (`id`)) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40000 ALTER TABLE `box_2_csp3_subscribers` DISABLE KEYS */;
SET FOREIGN_KEY_CHECKS = 0;
SET UNIQUE_CHECKS = 0;
/*!40000 ALTER TABLE `box_2_csp3_subscribers` ENABLE KEYS */;
SET FOREIGN_KEY_CHECKS = 1;
SET UNIQUE_CHECKS = 1;
