CREATE TABLE `box_2_rspointexpiry` (  `id` mediumint(9) NOT NULL AUTO_INCREMENT,  `earnedpoints` float DEFAULT NULL,  `usedpoints` float DEFAULT NULL,  `expiredpoints` float DEFAULT NULL,  `userid` int(99) DEFAULT NULL,  `earneddate` varchar(999) NOT NULL,  `expirydate` varchar(999) NOT NULL,  `checkpoints` varchar(999) NOT NULL,  `orderid` int(99) DEFAULT NULL,  `totalearnedpoints` int(99) DEFAULT NULL,  `totalredeempoints` int(99) DEFAULT NULL,  `reasonindetail` varchar(999) DEFAULT NULL,  UNIQUE KEY `id` (`id`)) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40000 ALTER TABLE `box_2_rspointexpiry` DISABLE KEYS */;
SET FOREIGN_KEY_CHECKS = 0;
SET UNIQUE_CHECKS = 0;
/*!40000 ALTER TABLE `box_2_rspointexpiry` ENABLE KEYS */;
SET FOREIGN_KEY_CHECKS = 1;
SET UNIQUE_CHECKS = 1;
