CREATE TABLE `box_2_rating_form_user_role` (  `user_role_form_id` bigint(20) NOT NULL,  `user_role` varchar(50) NOT NULL,  PRIMARY KEY (`user_role_form_id`,`user_role`)) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40000 ALTER TABLE `box_2_rating_form_user_role` DISABLE KEYS */;
SET FOREIGN_KEY_CHECKS = 0;
SET UNIQUE_CHECKS = 0;
/*!40000 ALTER TABLE `box_2_rating_form_user_role` ENABLE KEYS */;
SET FOREIGN_KEY_CHECKS = 1;
SET UNIQUE_CHECKS = 1;
