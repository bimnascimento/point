CREATE TABLE `box_wysija_custom_field` (  `id` mediumint(9) NOT NULL AUTO_INCREMENT,  `name` tinytext NOT NULL,  `type` tinytext NOT NULL,  `required` tinyint(1) NOT NULL DEFAULT '0',  `settings` text,  PRIMARY KEY (`id`)) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40000 ALTER TABLE `box_wysija_custom_field` DISABLE KEYS */;
SET FOREIGN_KEY_CHECKS = 0;
SET UNIQUE_CHECKS = 0;
/*!40000 ALTER TABLE `box_wysija_custom_field` ENABLE KEYS */;
SET FOREIGN_KEY_CHECKS = 1;
SET UNIQUE_CHECKS = 1;
