CREATE TABLE `box_3_wysija_user` (  `user_id` int(10) unsigned NOT NULL AUTO_INCREMENT,  `wpuser_id` int(10) unsigned NOT NULL DEFAULT '0',  `email` varchar(255) NOT NULL,  `firstname` varchar(255) NOT NULL DEFAULT '',  `lastname` varchar(255) NOT NULL DEFAULT '',  `ip` varchar(100) NOT NULL,  `confirmed_ip` varchar(100) NOT NULL DEFAULT '0',  `confirmed_at` int(10) unsigned DEFAULT NULL,  `last_opened` int(10) unsigned DEFAULT NULL,  `last_clicked` int(10) unsigned DEFAULT NULL,  `keyuser` varchar(255) NOT NULL DEFAULT '',  `created_at` int(10) unsigned DEFAULT NULL,  `status` tinyint(4) NOT NULL DEFAULT '0',  `domain` varchar(255) DEFAULT '',  PRIMARY KEY (`user_id`),  UNIQUE KEY `EMAIL_UNIQUE` (`email`)) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40000 ALTER TABLE `box_3_wysija_user` DISABLE KEYS */;
SET FOREIGN_KEY_CHECKS = 0;
SET UNIQUE_CHECKS = 0;
INSERT INTO `box_3_wysija_user` VALUES('1', '3', 'contato.tr@pointlave.com.br', '', '', '', '0', NULL, NULL, NULL, '', '1494667283', '1', 'www.pointlave.com.br');
INSERT INTO `box_3_wysija_user` VALUES('3', '35', 'lavanderiatr@pointlave.com.br', 'Lavanderia', 'Três Rios', '192.168.1.25', '0', NULL, NULL, NULL, 'b484014b046d38ed218d71a5fe1bed11', '1500087508', '1', 'fastlave.com.br');
/*!40000 ALTER TABLE `box_3_wysija_user` ENABLE KEYS */;
SET FOREIGN_KEY_CHECKS = 1;
SET UNIQUE_CHECKS = 1;
