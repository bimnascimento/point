CREATE TABLE `box_arf_ref_forms` (  `id` int(11) NOT NULL AUTO_INCREMENT,  `form_key` varchar(25) DEFAULT NULL,  `name` varchar(255) DEFAULT NULL,  `description` text,  `is_loggedin` tinyint(1) DEFAULT NULL,  `can_edit` tinyint(1) DEFAULT NULL,  `is_template` tinyint(1) DEFAULT '0',  `status` varchar(255) DEFAULT NULL,  `options` longtext,  `created_date` datetime NOT NULL,  `autoresponder_id` varchar(255) DEFAULT NULL,  `autoresponder_fname` varchar(255) DEFAULT NULL,  `autoresponder_lname` varchar(255) DEFAULT NULL,  `autoresponder_email` varchar(255) DEFAULT NULL,  `is_enable` int(11) NOT NULL DEFAULT '1',  `columns_list` text,  `form_css` longtext,  `form_id` int(11) NOT NULL DEFAULT '0',  PRIMARY KEY (`id`),  UNIQUE KEY `form_key` (`form_key`)) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40000 ALTER TABLE `box_arf_ref_forms` DISABLE KEYS */;
SET FOREIGN_KEY_CHECKS = 0;
SET UNIQUE_CHECKS = 0;
/*!40000 ALTER TABLE `box_arf_ref_forms` ENABLE KEYS */;
SET FOREIGN_KEY_CHECKS = 1;
SET UNIQUE_CHECKS = 1;
