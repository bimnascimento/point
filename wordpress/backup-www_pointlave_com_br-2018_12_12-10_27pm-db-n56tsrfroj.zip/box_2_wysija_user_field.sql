CREATE TABLE `box_2_wysija_user_field` (  `field_id` int(10) unsigned NOT NULL AUTO_INCREMENT,  `name` varchar(250) DEFAULT NULL,  `column_name` varchar(250) NOT NULL DEFAULT '',  `type` tinyint(3) unsigned DEFAULT '0',  `values` text,  `default` varchar(250) NOT NULL DEFAULT '',  `is_required` tinyint(3) unsigned NOT NULL DEFAULT '0',  `error_message` varchar(250) NOT NULL DEFAULT '',  PRIMARY KEY (`field_id`)) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40000 ALTER TABLE `box_2_wysija_user_field` DISABLE KEYS */;
SET FOREIGN_KEY_CHECKS = 0;
SET UNIQUE_CHECKS = 0;
INSERT INTO `box_2_wysija_user_field` VALUES('1', 'Nome', 'firstname', '0', NULL, '', '0', 'Por favor, digite seu nome');
INSERT INTO `box_2_wysija_user_field` VALUES('2', 'Sobrenome', 'lastname', '0', NULL, '', '0', 'Por favor, digite seu sobrenome');
/*!40000 ALTER TABLE `box_2_wysija_user_field` ENABLE KEYS */;
SET FOREIGN_KEY_CHECKS = 1;
SET UNIQUE_CHECKS = 1;
