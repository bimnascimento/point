CREATE TABLE `box_3_wysija_url_mail` (  `email_id` int(11) NOT NULL AUTO_INCREMENT,  `url_id` int(10) unsigned NOT NULL,  `unique_clicked` int(10) unsigned NOT NULL DEFAULT '0',  `total_clicked` int(10) unsigned NOT NULL DEFAULT '0',  PRIMARY KEY (`email_id`,`url_id`)) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40000 ALTER TABLE `box_3_wysija_url_mail` DISABLE KEYS */;
SET FOREIGN_KEY_CHECKS = 0;
SET UNIQUE_CHECKS = 0;
/*!40000 ALTER TABLE `box_3_wysija_url_mail` ENABLE KEYS */;
SET FOREIGN_KEY_CHECKS = 1;
SET UNIQUE_CHECKS = 1;
