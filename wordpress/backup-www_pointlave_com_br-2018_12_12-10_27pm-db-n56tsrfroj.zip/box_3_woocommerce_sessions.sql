CREATE TABLE `box_3_woocommerce_sessions` (  `session_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,  `session_key` char(32) NOT NULL,  `session_value` longtext NOT NULL,  `session_expiry` bigint(20) unsigned NOT NULL,  PRIMARY KEY (`session_key`),  UNIQUE KEY `session_id` (`session_id`)) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8;
/*!40000 ALTER TABLE `box_3_woocommerce_sessions` DISABLE KEYS */;
SET FOREIGN_KEY_CHECKS = 0;
SET UNIQUE_CHECKS = 0;
/*!40000 ALTER TABLE `box_3_woocommerce_sessions` ENABLE KEYS */;
SET FOREIGN_KEY_CHECKS = 1;
SET UNIQUE_CHECKS = 1;
