CREATE TABLE `box_hmapsprem_marker_categories` (  `category_id` int(11) NOT NULL AUTO_INCREMENT,  `name` varchar(45) NOT NULL,  `imported` tinyint(1) NOT NULL DEFAULT '0',  `deleted` tinyint(1) NOT NULL DEFAULT '0',  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,  PRIMARY KEY (`category_id`)) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40000 ALTER TABLE `box_hmapsprem_marker_categories` DISABLE KEYS */;
SET FOREIGN_KEY_CHECKS = 0;
SET UNIQUE_CHECKS = 0;
INSERT INTO `box_hmapsprem_marker_categories` VALUES('1', 'brasil', '1', '0', '2017-05-26 00:18:23');
INSERT INTO `box_hmapsprem_marker_categories` VALUES('2', 'Custom', '0', '0', '2017-05-26 00:19:43');
/*!40000 ALTER TABLE `box_hmapsprem_marker_categories` ENABLE KEYS */;
SET FOREIGN_KEY_CHECKS = 1;
SET UNIQUE_CHECKS = 1;
