CREATE TABLE `box_2_rs_templates_email` (  `id` mediumint(9) NOT NULL AUTO_INCREMENT,  `template_name` longtext NOT NULL,  `sender_opt` varchar(10) NOT NULL DEFAULT 'woo',  `from_name` longtext NOT NULL,  `from_email` longtext NOT NULL,  `subject` longtext NOT NULL,  `message` longtext NOT NULL,  `earningpoints` longtext NOT NULL,  `redeemingpoints` longtext NOT NULL,  `mailsendingoptions` longtext NOT NULL,  `rsmailsendingoptions` longtext NOT NULL,  `minimum_userpoints` longtext NOT NULL,  `sendmail_options` varchar(10) NOT NULL DEFAULT '1',  `sendmail_to` longtext NOT NULL,  `sending_type` varchar(20) NOT NULL,  `rs_status` varchar(10) NOT NULL DEFAULT 'DEACTIVATE',  UNIQUE KEY `id` (`id`)) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40000 ALTER TABLE `box_2_rs_templates_email` DISABLE KEYS */;
SET FOREIGN_KEY_CHECKS = 0;
SET UNIQUE_CHECKS = 0;
INSERT INTO `box_2_rs_templates_email` VALUES('1', 'Default', 'woo', 'Admin', 'contato.jf@pointlave.com.br', 'SUMO Rewards Point', 'Hi {rsfirstname} {rslastname}, <br><br> You have Earned Reward Points: {rspoints} on {rssitelink}  <br><br> You can use this Reward Points to make discounted purchases on {rssitelink} <br><br> Thanks', '', '', '2', '3', '0', '1', '', '', 'DEACTIVATE');
/*!40000 ALTER TABLE `box_2_rs_templates_email` ENABLE KEYS */;
SET FOREIGN_KEY_CHECKS = 1;
SET UNIQUE_CHECKS = 1;
