CREATE TABLE `box_3_rating_form_block_ip` (  `ip` varchar(50) NOT NULL,  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,  `reason` text NOT NULL,  PRIMARY KEY (`ip`)) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40000 ALTER TABLE `box_3_rating_form_block_ip` DISABLE KEYS */;
SET FOREIGN_KEY_CHECKS = 0;
SET UNIQUE_CHECKS = 0;
/*!40000 ALTER TABLE `box_3_rating_form_block_ip` ENABLE KEYS */;
SET FOREIGN_KEY_CHECKS = 1;
SET UNIQUE_CHECKS = 1;
