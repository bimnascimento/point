CREATE TABLE `box_3_wysija_campaign` (  `campaign_id` int(10) unsigned NOT NULL AUTO_INCREMENT,  `name` varchar(250) DEFAULT NULL,  `description` text,  PRIMARY KEY (`campaign_id`)) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40000 ALTER TABLE `box_3_wysija_campaign` DISABLE KEYS */;
SET FOREIGN_KEY_CHECKS = 0;
SET UNIQUE_CHECKS = 0;
INSERT INTO `box_3_wysija_campaign` VALUES('1', 'Guia de Usuário de 5 Minutos', '');
/*!40000 ALTER TABLE `box_3_wysija_campaign` ENABLE KEYS */;
SET FOREIGN_KEY_CHECKS = 1;
SET UNIQUE_CHECKS = 1;
