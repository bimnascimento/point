CREATE TABLE `box_3_realmedialibrary` (  `id` mediumint(9) NOT NULL AUTO_INCREMENT,  `parent` mediumint(9) NOT NULL DEFAULT '-1',  `name` tinytext NOT NULL,  `slug` text NOT NULL,  `absolute` text NOT NULL,  `ord` mediumint(10) NOT NULL DEFAULT '0',  `contentCustomOrder` tinyint(1) NOT NULL DEFAULT '0',  `type` varchar(10) NOT NULL DEFAULT '0',  `restrictions` varchar(255) NOT NULL DEFAULT '',  `cnt` mediumint(10) DEFAULT NULL,  UNIQUE KEY `id` (`id`)) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40000 ALTER TABLE `box_3_realmedialibrary` DISABLE KEYS */;
SET FOREIGN_KEY_CHECKS = 0;
SET UNIQUE_CHECKS = 0;
INSERT INTO `box_3_realmedialibrary` VALUES('1', '-1', 'Itens', 'Itens', 'Itens', '1', '0', '0', '', '0');
INSERT INTO `box_3_realmedialibrary` VALUES('2', '1', 'Roupas de Cama', 'Roupas-de-Cama', 'Itens/Roupas-de-Cama', '1', '0', '0', '', '5');
/*!40000 ALTER TABLE `box_3_realmedialibrary` ENABLE KEYS */;
SET FOREIGN_KEY_CHECKS = 1;
SET UNIQUE_CHECKS = 1;
