CREATE TABLE `box_2_woocommerce_payment_tokenmeta` (  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,  `payment_token_id` bigint(20) unsigned NOT NULL,  `meta_key` varchar(255) DEFAULT NULL,  `meta_value` longtext,  PRIMARY KEY (`meta_id`),  KEY `payment_token_id` (`payment_token_id`),  KEY `meta_key` (`meta_key`(32))) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40000 ALTER TABLE `box_2_woocommerce_payment_tokenmeta` DISABLE KEYS */;
SET FOREIGN_KEY_CHECKS = 0;
SET UNIQUE_CHECKS = 0;
/*!40000 ALTER TABLE `box_2_woocommerce_payment_tokenmeta` ENABLE KEYS */;
SET FOREIGN_KEY_CHECKS = 1;
SET UNIQUE_CHECKS = 1;
