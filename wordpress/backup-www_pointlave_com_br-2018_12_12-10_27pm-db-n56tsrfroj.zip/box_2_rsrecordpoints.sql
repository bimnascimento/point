CREATE TABLE `box_2_rsrecordpoints` (  `id` mediumint(9) NOT NULL AUTO_INCREMENT,  `earnedpoints` float DEFAULT NULL,  `redeempoints` float DEFAULT NULL,  `userid` int(99) DEFAULT NULL,  `earneddate` varchar(999) NOT NULL,  `expirydate` varchar(999) NOT NULL,  `checkpoints` varchar(999) NOT NULL,  `earnedequauivalentamount` int(99) DEFAULT NULL,  `redeemequauivalentamount` int(99) DEFAULT NULL,  `orderid` int(99) DEFAULT NULL,  `productid` int(99) DEFAULT NULL,  `variationid` int(99) DEFAULT NULL,  `refuserid` int(99) DEFAULT NULL,  `reasonindetail` varchar(999) DEFAULT NULL,  `totalpoints` int(99) DEFAULT NULL,  `showmasterlog` varchar(999) DEFAULT NULL,  `showuserlog` varchar(999) DEFAULT NULL,  `nomineeid` int(99) DEFAULT NULL,  `nomineepoints` int(99) DEFAULT NULL,  UNIQUE KEY `id` (`id`)) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40000 ALTER TABLE `box_2_rsrecordpoints` DISABLE KEYS */;
SET FOREIGN_KEY_CHECKS = 0;
SET UNIQUE_CHECKS = 0;
/*!40000 ALTER TABLE `box_2_rsrecordpoints` ENABLE KEYS */;
SET FOREIGN_KEY_CHECKS = 1;
SET UNIQUE_CHECKS = 1;
