CREATE TABLE `box_3_rating_form` (  `form_id` bigint(20) NOT NULL AUTO_INCREMENT,  `form_name` varchar(50) NOT NULL,  `active` int(11) NOT NULL DEFAULT '1',  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,  `type` int(11) NOT NULL DEFAULT '1',  `max` int(11) NOT NULL DEFAULT '5',  `restrict_ip` int(11) NOT NULL DEFAULT '1',  `user_logged_in` int(11) NOT NULL,  `ajax_load` int(11) NOT NULL,  `rich_snippet` int(11) NOT NULL,  `spinner` int(11) NOT NULL DEFAULT '1',  `round` int(11) NOT NULL DEFAULT '1',  `rtl` int(11) NOT NULL,  `limitation` int(11) NOT NULL DEFAULT '1',  `time` bigint(20) NOT NULL,  `display` text NOT NULL,  `txt_ty` text NOT NULL,  `txt_rated` text NOT NULL,  `txt_login` text NOT NULL,  `txt_limit` text NOT NULL,  `txt_edit_rating` text NOT NULL,  PRIMARY KEY (`form_id`)) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40000 ALTER TABLE `box_3_rating_form` DISABLE KEYS */;
SET FOREIGN_KEY_CHECKS = 0;
SET UNIQUE_CHECKS = 0;
INSERT INTO `box_3_rating_form` VALUES('1', 'lavanderias-vote', '1', '2017-07-14 18:56:56', '1', '5', '1', '1', '0', '0', '1', '1', '0', '2', '0', '[\"spinner3\"]', 'Obrigado :)', 'Você já avaliou!', 'Faça seu login para avaliar!', 'Desculpe, a avaliação é limitada. Você pode avaliar novamente em %4$d dias %3$d horas %2$d minutos %1$d segundos.', 'Você encontra este resultado em %2$s');
/*!40000 ALTER TABLE `box_3_rating_form` ENABLE KEYS */;
SET FOREIGN_KEY_CHECKS = 1;
SET UNIQUE_CHECKS = 1;
