CREATE TABLE `box_2_woocommerce_api_keys` (  `key_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,  `user_id` bigint(20) unsigned NOT NULL,  `description` varchar(200) DEFAULT NULL,  `permissions` varchar(10) NOT NULL,  `consumer_key` char(64) NOT NULL,  `consumer_secret` char(43) NOT NULL,  `nonces` longtext,  `truncated_key` char(7) NOT NULL,  `last_access` datetime DEFAULT NULL,  PRIMARY KEY (`key_id`),  KEY `consumer_key` (`consumer_key`),  KEY `consumer_secret` (`consumer_secret`)) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40000 ALTER TABLE `box_2_woocommerce_api_keys` DISABLE KEYS */;
SET FOREIGN_KEY_CHECKS = 0;
SET UNIQUE_CHECKS = 0;
/*!40000 ALTER TABLE `box_2_woocommerce_api_keys` ENABLE KEYS */;
SET FOREIGN_KEY_CHECKS = 1;
SET UNIQUE_CHECKS = 1;
