CREATE TABLE `box_2_wpml_mails` (  `mail_id` int(11) NOT NULL AUTO_INCREMENT,  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,  `host` varchar(200) NOT NULL DEFAULT '0',  `receiver` varchar(200) NOT NULL DEFAULT '0',  `subject` varchar(200) NOT NULL DEFAULT '0',  `message` text,  `headers` text,  `attachments` varchar(800) NOT NULL DEFAULT '0',  `error` varchar(400) DEFAULT '',  `plugin_version` varchar(200) NOT NULL DEFAULT '0',  PRIMARY KEY (`mail_id`)) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=utf8;
/*!40000 ALTER TABLE `box_2_wpml_mails` DISABLE KEYS */;
SET FOREIGN_KEY_CHECKS = 0;
SET UNIQUE_CHECKS = 0;
/*!40000 ALTER TABLE `box_2_wpml_mails` ENABLE KEYS */;
SET FOREIGN_KEY_CHECKS = 1;
SET UNIQUE_CHECKS = 1;
