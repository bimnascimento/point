CREATE TABLE `box_3_dokan_refund` (  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,  `order_id` bigint(20) unsigned NOT NULL,  `seller_id` bigint(20) NOT NULL,  `refund_amount` float NOT NULL,  `refund_reason` text,  `item_qtys` varchar(50) DEFAULT NULL,  `item_totals` varchar(50) DEFAULT NULL,  `item_tax_totals` varchar(50) DEFAULT NULL,  `restock_items` varchar(10) DEFAULT NULL,  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,  `status` int(1) NOT NULL,  `method` varchar(30) NOT NULL,  PRIMARY KEY (`id`)) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40000 ALTER TABLE `box_3_dokan_refund` DISABLE KEYS */;
SET FOREIGN_KEY_CHECKS = 0;
SET UNIQUE_CHECKS = 0;
/*!40000 ALTER TABLE `box_3_dokan_refund` ENABLE KEYS */;
SET FOREIGN_KEY_CHECKS = 1;
SET UNIQUE_CHECKS = 1;
