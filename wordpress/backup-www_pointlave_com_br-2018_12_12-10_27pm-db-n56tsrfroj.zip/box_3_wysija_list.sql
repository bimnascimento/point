CREATE TABLE `box_3_wysija_list` (  `list_id` int(10) unsigned NOT NULL AUTO_INCREMENT,  `name` varchar(250) DEFAULT NULL,  `namekey` varchar(255) DEFAULT NULL,  `description` text,  `unsub_mail_id` int(10) unsigned NOT NULL DEFAULT '0',  `welcome_mail_id` int(10) unsigned NOT NULL DEFAULT '0',  `is_enabled` tinyint(3) unsigned NOT NULL DEFAULT '0',  `is_public` tinyint(3) unsigned NOT NULL DEFAULT '0',  `created_at` int(10) unsigned DEFAULT NULL,  `ordering` int(10) unsigned NOT NULL DEFAULT '0',  PRIMARY KEY (`list_id`)) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40000 ALTER TABLE `box_3_wysija_list` DISABLE KEYS */;
SET FOREIGN_KEY_CHECKS = 0;
SET UNIQUE_CHECKS = 0;
INSERT INTO `box_3_wysija_list` VALUES('1', 'Minha primeira lista', 'minha-primeira-lista', 'A lista criada automaticamente na instalação do MailPoet.', '0', '0', '1', '1', '1494667281', '0');
INSERT INTO `box_3_wysija_list` VALUES('2', 'Usuários do WordPress', 'users', 'A lista criada automaticamente na importação dos assinantes do plugin : \"WordPress', '0', '0', '0', '0', '1494667282', '0');
/*!40000 ALTER TABLE `box_3_wysija_list` ENABLE KEYS */;
SET FOREIGN_KEY_CHECKS = 1;
SET UNIQUE_CHECKS = 1;
