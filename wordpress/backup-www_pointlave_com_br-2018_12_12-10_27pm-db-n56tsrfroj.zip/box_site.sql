CREATE TABLE `box_site` (  `id` bigint(20) NOT NULL AUTO_INCREMENT,  `domain` varchar(200) NOT NULL DEFAULT '',  `path` varchar(100) NOT NULL DEFAULT '',  PRIMARY KEY (`id`),  KEY `domain` (`domain`(140),`path`(51))) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40000 ALTER TABLE `box_site` DISABLE KEYS */;
SET FOREIGN_KEY_CHECKS = 0;
SET UNIQUE_CHECKS = 0;
INSERT INTO `box_site` VALUES('1', 'www.pointlave.com.br', '/');
/*!40000 ALTER TABLE `box_site` ENABLE KEYS */;
SET FOREIGN_KEY_CHECKS = 1;
SET UNIQUE_CHECKS = 1;
