CREATE TABLE `box_3_rating_form_rated` (  `rate_id` bigint(20) NOT NULL AUTO_INCREMENT,  `post_id` bigint(20) NOT NULL,  `comment_id` bigint(20) NOT NULL,  `custom_id` varchar(20) NOT NULL DEFAULT '0',  `user_id` bigint(20) NOT NULL,  `term_id` bigint(20) NOT NULL,  `ip` varchar(50) NOT NULL,  `rated` varchar(11) NOT NULL,  `user` bigint(20) NOT NULL,  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,  PRIMARY KEY (`rate_id`)) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40000 ALTER TABLE `box_3_rating_form_rated` DISABLE KEYS */;
SET FOREIGN_KEY_CHECKS = 0;
SET UNIQUE_CHECKS = 0;
/*!40000 ALTER TABLE `box_3_rating_form_rated` ENABLE KEYS */;
SET FOREIGN_KEY_CHECKS = 1;
SET UNIQUE_CHECKS = 1;
