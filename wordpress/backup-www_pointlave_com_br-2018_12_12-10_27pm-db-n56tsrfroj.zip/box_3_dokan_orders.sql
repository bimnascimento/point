CREATE TABLE `box_3_dokan_orders` (  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,  `order_id` bigint(20) DEFAULT NULL,  `seller_id` bigint(20) DEFAULT NULL,  `order_total` float(11,2) DEFAULT NULL,  `net_amount` float(11,2) DEFAULT NULL,  `order_status` varchar(30) DEFAULT NULL,  PRIMARY KEY (`id`),  KEY `order_id` (`order_id`),  KEY `seller_id` (`seller_id`)) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40000 ALTER TABLE `box_3_dokan_orders` DISABLE KEYS */;
SET FOREIGN_KEY_CHECKS = 0;
SET UNIQUE_CHECKS = 0;
/*!40000 ALTER TABLE `box_3_dokan_orders` ENABLE KEYS */;
SET FOREIGN_KEY_CHECKS = 1;
SET UNIQUE_CHECKS = 1;
