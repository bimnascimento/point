CREATE TABLE `box_realmedialibrary` (  `id` mediumint(9) NOT NULL AUTO_INCREMENT,  `parent` mediumint(9) NOT NULL DEFAULT '-1',  `name` tinytext NOT NULL,  `slug` text NOT NULL,  `absolute` text NOT NULL,  `ord` mediumint(10) NOT NULL DEFAULT '0',  `contentCustomOrder` tinyint(1) NOT NULL DEFAULT '0',  `type` varchar(10) NOT NULL DEFAULT '0',  `restrictions` varchar(255) NOT NULL DEFAULT '',  `cnt` mediumint(10) DEFAULT NULL,  UNIQUE KEY `id` (`id`)) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40000 ALTER TABLE `box_realmedialibrary` DISABLE KEYS */;
SET FOREIGN_KEY_CHECKS = 0;
SET UNIQUE_CHECKS = 0;
/*!40000 ALTER TABLE `box_realmedialibrary` ENABLE KEYS */;
SET FOREIGN_KEY_CHECKS = 1;
SET UNIQUE_CHECKS = 1;
