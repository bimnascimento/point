CREATE TABLE `box_wysija_email_user_stat` (  `user_id` int(10) unsigned NOT NULL,  `email_id` int(10) unsigned NOT NULL,  `sent_at` int(10) unsigned NOT NULL,  `opened_at` int(10) unsigned DEFAULT NULL,  `status` tinyint(4) NOT NULL DEFAULT '0',  PRIMARY KEY (`user_id`,`email_id`)) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40000 ALTER TABLE `box_wysija_email_user_stat` DISABLE KEYS */;
SET FOREIGN_KEY_CHECKS = 0;
SET UNIQUE_CHECKS = 0;
/*!40000 ALTER TABLE `box_wysija_email_user_stat` ENABLE KEYS */;
SET FOREIGN_KEY_CHECKS = 1;
SET UNIQUE_CHECKS = 1;
