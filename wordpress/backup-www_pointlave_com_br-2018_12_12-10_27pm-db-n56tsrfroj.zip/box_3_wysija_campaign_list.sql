CREATE TABLE `box_3_wysija_campaign_list` (  `list_id` int(10) unsigned NOT NULL,  `campaign_id` int(10) unsigned NOT NULL,  `filter` text,  PRIMARY KEY (`list_id`,`campaign_id`)) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40000 ALTER TABLE `box_3_wysija_campaign_list` DISABLE KEYS */;
SET FOREIGN_KEY_CHECKS = 0;
SET UNIQUE_CHECKS = 0;
/*!40000 ALTER TABLE `box_3_wysija_campaign_list` ENABLE KEYS */;
SET FOREIGN_KEY_CHECKS = 1;
SET UNIQUE_CHECKS = 1;
