CREATE TABLE `box_3_wpie_export_log` (  `export_log_id` int(11) NOT NULL AUTO_INCREMENT,  `export_log_file_type` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,  `export_log_file_name` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,  `export_log_data` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,  `create_date` datetime NOT NULL,  PRIMARY KEY (`export_log_id`)) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40000 ALTER TABLE `box_3_wpie_export_log` DISABLE KEYS */;
SET FOREIGN_KEY_CHECKS = 0;
SET UNIQUE_CHECKS = 0;
INSERT INTO `box_3_wpie_export_log` VALUES('1', 'import', 'product_category_2017_06_14_23_07_43.csv', 'Product Category', '2017-07-14 00:20:07');
/*!40000 ALTER TABLE `box_3_wpie_export_log` ENABLE KEYS */;
SET FOREIGN_KEY_CHECKS = 1;
SET UNIQUE_CHECKS = 1;
