CREATE TABLE `box_3_rating_form_post_type` (  `post_type_form_id` bigint(20) NOT NULL,  `post_type` varchar(20) NOT NULL,  PRIMARY KEY (`post_type_form_id`,`post_type`)) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40000 ALTER TABLE `box_3_rating_form_post_type` DISABLE KEYS */;
SET FOREIGN_KEY_CHECKS = 0;
SET UNIQUE_CHECKS = 0;
/*!40000 ALTER TABLE `box_3_rating_form_post_type` ENABLE KEYS */;
SET FOREIGN_KEY_CHECKS = 1;
SET UNIQUE_CHECKS = 1;
