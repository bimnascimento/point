CREATE TABLE `box_3_woocommerce_order_items` (  `order_item_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,  `order_item_name` text NOT NULL,  `order_item_type` varchar(200) NOT NULL DEFAULT '',  `order_id` bigint(20) unsigned NOT NULL,  PRIMARY KEY (`order_item_id`),  KEY `order_id` (`order_id`)) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40000 ALTER TABLE `box_3_woocommerce_order_items` DISABLE KEYS */;
SET FOREIGN_KEY_CHECKS = 0;
SET UNIQUE_CHECKS = 0;
/*!40000 ALTER TABLE `box_3_woocommerce_order_items` ENABLE KEYS */;
SET FOREIGN_KEY_CHECKS = 1;
SET UNIQUE_CHECKS = 1;
