CREATE TABLE `box_3_woocommerce_shipping_zone_methods` (  `zone_id` bigint(20) unsigned NOT NULL,  `instance_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,  `method_id` varchar(200) NOT NULL,  `method_order` bigint(20) unsigned NOT NULL,  `is_enabled` tinyint(1) NOT NULL DEFAULT '1',  PRIMARY KEY (`instance_id`)) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40000 ALTER TABLE `box_3_woocommerce_shipping_zone_methods` DISABLE KEYS */;
SET FOREIGN_KEY_CHECKS = 0;
SET UNIQUE_CHECKS = 0;
INSERT INTO `box_3_woocommerce_shipping_zone_methods` VALUES('0', '1', 'free_shipping', '1', '1');
/*!40000 ALTER TABLE `box_3_woocommerce_shipping_zone_methods` ENABLE KEYS */;
SET FOREIGN_KEY_CHECKS = 1;
SET UNIQUE_CHECKS = 1;
